const { createClient } = require('@supabase/supabase-js');

const supabase = createClient(
  "https://dcipszrpnshxdmxedfpn.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImRjaXBzenJwbnNoeGRteGVkZnBuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM5MTMzMjksImV4cCI6MjA4OTQ4OTMyOX0.0MpLB835iCmz7e-HQLaA89bXMY4YOsRlvdp835RZBs4"
);

async function check() {
  const { data, error } = await supabase.from('data_records').select('*').limit(1);
  if (error) {
    console.error('Error:', error);
    return;
  }
  if (data && data.length > 0) {
    console.log('Columns found in data_records:', Object.keys(data[0]));
  } else {
    console.log('No records found to inspect.');
    const checks = ['batch_id', 'filename', 'source_file', 'batch_name'];
    for (const c of checks) {
       const { error: err } = await supabase.from('data_records').select(c).limit(1);
       console.log(`Exists ${c}?`, !err);
    }
  }
}

check();
