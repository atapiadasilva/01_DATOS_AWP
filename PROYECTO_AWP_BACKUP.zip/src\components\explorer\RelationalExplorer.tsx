'use client';

import React, { useState, useEffect, useMemo } from 'react';
import { Database, Plus, X, ChevronRight, Layers, Search, ArrowRight, Check, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface RelationalExplorerProps {
  entities: any[];
  relationships: any[];
}

interface SelectedColumn {
  entityId: string;
  entityName: string;
  column: string;
  alias?: string;
}

export default function RelationalExplorer({ entities, relationships }: RelationalExplorerProps) {
  const [baseEntityId, setBaseEntityId] = useState('');
  const [baseData, setBaseData] = useState<any[]>([]);
  const [baseColumns, setBaseColumns] = useState<string[]>([]);
  const [selectedBaseColumns, setSelectedBaseColumns] = useState<string[]>([]);
  const [selectedExtraColumns, setSelectedExtraColumns] = useState<SelectedColumn[]>([]);
  const [relatedEntityData, setRelatedEntityData] = useState<Record<string, any[]>>({});
  const [isLoading, setIsLoading] = useState(false);
  const [columnSearch, setColumnSearch] = useState('');
  const [expandedEntities, setExpandedEntities] = useState<Set<string>>(new Set());

  // ─── Entidades relacionadas con la base (1 hop) ───────────────────────
  const reachableEntities = useMemo(() => {
    if (!baseEntityId) return [];
    const result: { entity: any; joinKey: { parentCol: string; childCol: string }; direction: string }[] = [];
    relationships.forEach(rel => {
      const pEntityId = rel.parent_attr?.entity?.id;
      const cEntityId = rel.child_attr?.entity?.id;
      const pCol = rel.parent_attr?.name;
      const cCol = rel.child_attr?.name;

      if (pEntityId === baseEntityId && cEntityId && cEntityId !== baseEntityId) {
        const ent = entities.find(e => e.id === cEntityId);
        if (ent) result.push({ entity: ent, joinKey: { parentCol: pCol, childCol: cCol }, direction: 'parent' });
      }
      if (cEntityId === baseEntityId && pEntityId && pEntityId !== baseEntityId) {
        const ent = entities.find(e => e.id === pEntityId);
        if (ent) result.push({ entity: ent, joinKey: { parentCol: cCol, childCol: pCol }, direction: 'child' });
      }
    });
    // Dedup by entity id
    const seen = new Set<string>();
    return result.filter(r => { if (seen.has(r.entity.id)) return false; seen.add(r.entity.id); return true; });
  }, [baseEntityId, relationships, entities]);

  // ─── Cargar datos de entidad base ─────────────────────────────────────
  useEffect(() => {
    if (!baseEntityId) { setBaseData([]); setBaseColumns([]); setSelectedBaseColumns([]); setSelectedExtraColumns([]); setRelatedEntityData({}); return; }
    setIsLoading(true);
    supabase.from('data_records').select('id, data').eq('entity_id', baseEntityId).limit(500)
      .then(({ data }) => {
        if (data && data.length > 0) {
          const rows = data.map(r => ({ __id: r.id, ...r.data }));
          setBaseData(rows);
          const cols = Array.from(new Set(rows.flatMap(r => Object.keys(r).filter(k => !k.startsWith('_batch') && k !== '__id'))));
          setBaseColumns(cols);
          setSelectedBaseColumns(cols.slice(0, 5));
        } else {
          setBaseData([]); setBaseColumns([]);
        }
        setIsLoading(false);
      });
  }, [baseEntityId]);

  // ─── Cargar datos de entidades relacionadas cuando se agrega una columna extra ──
  const ensureRelatedData = async (entityId: string) => {
    if (relatedEntityData[entityId]) return;
    const { data } = await supabase.from('data_records').select('id, data').eq('entity_id', entityId).limit(500);
    if (data) {
      setRelatedEntityData(prev => ({ ...prev, [entityId]: data.map(r => ({ __id: r.id, ...r.data })) }));
    }
  };

  const addExtraColumn = async (entityId: string, entityName: string, column: string) => {
    if (selectedExtraColumns.find(c => c.entityId === entityId && c.column === column)) return;
    await ensureRelatedData(entityId);
    setSelectedExtraColumns(prev => [...prev, { entityId, entityName, column }]);
  };

  const removeExtraColumn = (entityId: string, column: string) => {
    setSelectedExtraColumns(prev => prev.filter(c => !(c.entityId === entityId && c.column === column)));
  };

  const toggleBaseColumn = (col: string) => {
    setSelectedBaseColumns(prev => prev.includes(col) ? prev.filter(c => c !== col) : [...prev, col]);
  };

  // ─── JOIN en memoria ──────────────────────────────────────────────────
  const joinedRows = useMemo(() => {
    return baseData.map(baseRow => {
      const merged: any = {};
      // Columnas base seleccionadas
      selectedBaseColumns.forEach(col => { merged[col] = baseRow[col]; });

      // Columnas extra (JOIN por la clave de relación)
      selectedExtraColumns.forEach(({ entityId, column }) => {
        const rel = reachableEntities.find(r => r.entity.id === entityId);
        if (!rel) return;
        const { parentCol, childCol } = rel.joinKey;
        const baseJoinVal = baseRow[parentCol];
        const relRows = relatedEntityData[entityId] || [];
        const matchRow = relRows.find(r => String(r[childCol] ?? '').trim().toLowerCase() === String(baseJoinVal ?? '').trim().toLowerCase());
        merged[`${entityId}::${column}`] = matchRow?.[column] ?? '—';
      });

      return merged;
    });
  }, [baseData, selectedBaseColumns, selectedExtraColumns, relatedEntityData, reachableEntities]);

  const allDisplayColumns = [
    ...selectedBaseColumns,
    ...selectedExtraColumns.map(c => `${c.entityId}::${c.column}`)
  ];

  const getColumnLabel = (col: string) => {
    if (!col.includes('::')) return col;
    const [entityId, column] = col.split('::');
    const ent = entities.find(e => e.id === entityId);
    return `${ent?.name?.slice(0, 12) ?? '?'} › ${column}`;
  };

  const getColumnColor = (col: string) => {
    if (!col.includes('::')) return 'bg-slate-100 text-slate-600';
    const [entityId] = col.split('::');
    const colors = ['bg-blue-50 text-blue-600', 'bg-purple-50 text-purple-600', 'bg-amber-50 text-amber-700', 'bg-rose-50 text-rose-600', 'bg-teal-50 text-teal-600'];
    const idx = entities.findIndex(e => e.id === entityId) % colors.length;
    return colors[idx];
  };

  const baseEntity = entities.find(e => e.id === baseEntityId);

  return (
    <div className="flex h-full gap-0 overflow-hidden">
      {/* ─────────────────── PANEL IZQUIERDO: Selector de columnas ─────────────────── */}
      <div className="w-80 shrink-0 bg-white border-r border-slate-100 flex flex-col overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">Tabla Base</h4>
          <select
            value={baseEntityId}
            onChange={e => setBaseEntityId(e.target.value)}
            className="w-full text-sm font-bold p-3 bg-slate-50 border border-slate-100 rounded-xl outline-none focus:border-[#7CB342] transition-colors"
          >
            <option value="">Seleccionar tabla...</option>
            {entities.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
          </select>
        </div>

        {baseEntityId && (
          <div className="flex-1 overflow-y-auto">
            {/* Columnas de la tabla base */}
            <div className="p-4 border-b border-slate-50">
              <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                <Database size={9} /> {baseEntity?.name}
              </p>
              <div className="space-y-1">
                {baseColumns.filter(c => !c.startsWith('_batch')).map(col => (
                  <button key={col}
                    onClick={() => toggleBaseColumn(col)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-[11px] font-bold transition-all ${selectedBaseColumns.includes(col)
                      ? 'bg-slate-900 text-white'
                      : 'text-slate-500 hover:bg-slate-50'
                    }`}
                  >
                    <span className="truncate">{col}</span>
                    {selectedBaseColumns.includes(col) && <Check size={11} className="shrink-0" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Tablas relacionadas */}
            {reachableEntities.length > 0 && (
              <div className="p-4">
                <p className="text-[9px] font-black text-slate-300 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                  <ArrowRight size={9} /> Tablas Conectadas
                </p>
                {reachableEntities.map(({ entity, joinKey }) => {
                  const isExpanded = expandedEntities.has(entity.id);
                  const relData = relatedEntityData[entity.id] || [];
                  const relCols = relData.length > 0
                    ? Array.from(new Set(relData.flatMap(r => Object.keys(r).filter(k => !k.startsWith('_batch') && k !== '__id'))))
                    : (entity.attributes?.map((a: any) => a.name) || []);

                  const colors = ['border-blue-200 bg-blue-50/50', 'border-purple-200 bg-purple-50/50', 'border-amber-200 bg-amber-50/50', 'border-rose-200 bg-rose-50/50', 'border-teal-200 bg-teal-50/50'];
                  const colorIdx = entities.findIndex(e => e.id === entity.id) % colors.length;

                  return (
                    <div key={entity.id} className={`rounded-2xl border mb-3 overflow-hidden ${colors[colorIdx]}`}>
                      <button
                        onClick={async () => {
                          if (!isExpanded) await ensureRelatedData(entity.id);
                          setExpandedEntities(prev => {
                            const next = new Set(prev);
                            isExpanded ? next.delete(entity.id) : next.add(entity.id);
                            return next;
                          });
                        }}
                        className="w-full flex items-center justify-between px-4 py-3"
                      >
                        <div className="text-left">
                          <p className="text-[11px] font-black text-slate-700 truncate">{entity.name}</p>
                          <p className="text-[9px] text-slate-400 font-bold">
                            JOIN por: <span className="text-slate-600">{joinKey.parentCol}</span>
                          </p>
                        </div>
                        <ChevronRight size={14} className={`text-slate-400 transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
                      </button>
                      {isExpanded && (
                        <div className="px-3 pb-3 space-y-1">
                          {relCols.map(col => {
                            const isAdded = selectedExtraColumns.some(c => c.entityId === entity.id && c.column === col);
                            return (
                              <button key={col}
                                onClick={() => isAdded ? removeExtraColumn(entity.id, col) : addExtraColumn(entity.id, entity.name, col)}
                                className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all ${isAdded
                                  ? 'bg-white text-slate-700 shadow-sm'
                                  : 'text-slate-500 hover:bg-white/70'
                                }`}
                              >
                                <span className="truncate">{col}</span>
                                {isAdded ? <X size={10} className="shrink-0 text-red-400" /> : <Plus size={10} className="shrink-0" />}
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            {reachableEntities.length === 0 && baseEntityId && (
              <div className="p-6 text-center">
                <p className="text-[11px] text-slate-300 italic font-bold">No hay relaciones definidas para esta tabla. Define relaciones en el Mapa Nodal.</p>
              </div>
            )}
          </div>
        )}
        {!baseEntityId && (
          <div className="flex-1 flex items-center justify-center p-6">
            <p className="text-[11px] text-slate-300 text-center italic font-bold">Selecciona una tabla base para ver sus columnas y las tablas conectadas.</p>
          </div>
        )}
      </div>

      {/* ─────────────────── ÁREA PRINCIPAL: Super Tabla ─────────────────── */}
      <div className="flex-1 flex flex-col overflow-hidden bg-slate-50/50">
        {/* Header con columnas seleccionadas como chips */}
        {allDisplayColumns.length > 0 && (
          <div className="shrink-0 px-6 py-4 bg-white border-b border-slate-100 flex items-center gap-3 overflow-x-auto">
            <span className="text-[9px] font-black text-slate-300 uppercase tracking-widest shrink-0">Columnas activas</span>
            {allDisplayColumns.map(col => (
              <span key={col} className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black whitespace-nowrap ${getColumnColor(col)}`}>
                {getColumnLabel(col)}
                {col.includes('::') && (
                  <button onClick={() => { const [eid, c] = col.split('::'); removeExtraColumn(eid, c); }} className="hover:opacity-60">
                    <X size={9} />
                  </button>
                )}
              </span>
            ))}
          </div>
        )}

        {/* Stats bar */}
        {baseEntityId && (
          <div className="shrink-0 px-6 py-3 flex items-center gap-6">
            <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">
              {isLoading ? 'Cargando...' : `${joinedRows.length} filas`}
            </p>
            <p className="text-[11px] font-black text-slate-300">
              {selectedBaseColumns.length} columnas base + {selectedExtraColumns.length} columnas relacionadas
            </p>
            {selectedExtraColumns.length > 0 && (
              <p className="text-[11px] font-bold text-[#7CB342] flex items-center gap-1.5">
                <Layers size={12} />
                {new Set(selectedExtraColumns.map(c => c.entityId)).size} tablas cruzadas
              </p>
            )}
          </div>
        )}

        {/* Tabla */}
        <div className="flex-1 overflow-auto px-6 pb-6">
          {isLoading ? (
            <div className="flex items-center justify-center h-40 gap-3 text-slate-300">
              <Loader2 className="animate-spin" size={24} />
              <span className="font-bold text-sm">Cargando datos...</span>
            </div>
          ) : joinedRows.length > 0 && allDisplayColumns.length > 0 ? (
            <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
              <div className="overflow-x-auto max-h-[calc(100vh-280px)] overflow-y-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead className="bg-slate-50 sticky top-0 z-10">
                    <tr>
                      {allDisplayColumns.map(col => (
                        <th key={col} className={`px-4 py-3 border-b border-slate-100 whitespace-nowrap`}>
                          <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-wide ${getColumnColor(col)}`}>
                            {getColumnLabel(col)}
                          </span>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {joinedRows.slice(0, 300).map((row, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/80 transition-colors">
                        {allDisplayColumns.map(col => (
                          <td key={col} className="px-4 py-2.5 max-w-[220px]">
                            <span className={`block truncate ${!row[col] || row[col] === '—' ? 'text-slate-300 italic text-[10px]' : 'text-slate-700'}`}>
                              {row[col] !== null && row[col] !== undefined ? String(row[col]) : '—'}
                            </span>
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : baseEntityId && !isLoading ? (
            <div className="flex flex-col items-center justify-center h-60 gap-4 text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-200">
                <Layers size={32} />
              </div>
              <p className="text-slate-300 font-bold text-sm italic">
                {allDisplayColumns.length === 0
                  ? 'Selecciona columnas del panel izquierdo para construir tu super tabla.'
                  : 'La entidad seleccionada no tiene registros cargados.'}
              </p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-60 gap-4 text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-200">
                <Database size={32} />
              </div>
              <p className="text-slate-300 font-bold text-sm italic">
                Selecciona una tabla base para comenzar a construir tu vista cruzada.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
