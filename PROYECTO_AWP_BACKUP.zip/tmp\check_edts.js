require('dotenv').config({ path: '.env.local' });
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);

(async () => {
  try {
    const { data: entities } = await supabase.from('entities').select('*').eq('name', 'PROGRAMA DEL PROYECTO');
    if (!entities || entities.length === 0) {
      console.log('No entity found');
      return;
    }
    const entityId = entities[0].id;
    const { data: records, error } = await supabase.from('data_records').select('data').eq('entity_id', entityId);
    if (error) throw error;

    const edts = records.map(r => String(r.data['EDT'] || r.data['edt'] || '')).filter(Boolean);
    const uniqueEdts = Array.from(new Set(edts)).sort();
    
    console.log('Total records:', records.length);
    console.log('Unique EDTs found:', uniqueEdts.length);
    console.log('Top 50 EDTs:');
    console.log(uniqueEdts.slice(0, 50));
    
    const deeper = uniqueEdts.filter(e => e.split('.').length > 2);
    console.log('EDTs with 3+ levels:', deeper.length);
    if (deeper.length > 0) {
        console.log('Samples of deep EDTs:');
        console.log(deeper.slice(0, 20));
    }
  } catch (err) {
    console.error(err);
  }
})();
