'use client';

import React, { useState, useEffect } from 'react';
import {
  Upload, FileText, Database, Settings, Trash2, Plus,
  Activity, X, Printer, Loader2, Save, Filter,
  ArrowRight, Check, ChevronRight, Layout, Network,
  BarChart3, Layers, ShoppingCart, Search
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import * as XLSX from 'xlsx';
import ReactFlow, {
  Background,
  Controls,
  Handle,
  Position,
  ReactFlowProvider,
  addEdge,
  useNodesState,
  useEdgesState,
  MarkerType
} from 'reactflow';
import 'reactflow/dist/style.css';

// Importaciones de componentes locales
import Sidebar from '@/components/layout/Sidebar';
import Topbar from '@/components/layout/Topbar';
import ModelingCanvas from '@/components/modeling/ModelingCanvas';
import RelationalExplorer from '@/components/explorer/RelationalExplorer';
import IntegrityAudit from '@/components/audit/IntegrityAudit';

// ─── Componente EmbeddedView (Vistas Personalizadas Reutilizables) ──────────────────────────
const EmbeddedView = ({ viewName, filterValue, customViews, title }: { viewName: string, filterValue?: string, customViews: any[], title?: string }) => {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [newRow, setNewRow] = useState<Record<string, string>>({});

  const view = customViews.find(v => v.name.toLowerCase() === viewName.toLowerCase());

  const loadViewData = async () => {
    if (!view) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      let query;

      if (view.table_name) {
        query = supabase.from(view.table_name).select('*');
        if (view.filter_key && filterValue) {
          const cleanFilterKey = view.filter_key.trim().toLowerCase();
          const filterIdx = (view.columns || []).findIndex((c: string) => c.trim().toLowerCase() === cleanFilterKey);
          if (filterIdx !== -1) {
            query = query.ilike(`col_${filterIdx}`, `%${String(filterValue).trim()}%`);
          }
        }
      } else {
        query = supabase.from('data_records').select('*').eq('entity_id', view.entity_id);
        if (view.filter_key && filterValue) {
          query = query.contains('data', { [view.filter_key]: filterValue });
        }
      }

      const { data: resultData, error } = await query.limit(500);

      if (!error && resultData) {
        const formatted = resultData.map((r: any) => {
          if (view.table_name) {
            const mapped: any = {};
            (view.columns || []).forEach((col: string, idx: number) => {
              mapped[col] = r[`col_${idx}`];
            });
            return { id: r._record_id, data: mapped };
          }
          return { id: r.id, data: r.data };
        });
        setData(formatted);
      }
    } catch (err) {
      console.error('Error loading embedded view:', err);
    } finally {
      setLoading(false);
    }
  };

  React.useEffect(() => {
    loadViewData();
  }, [view, filterValue]);

  const handleDelete = async (recordId: string) => {
    if (!confirm('¿Estás seguro de eliminar este registro del sistema?')) return;
    try {
      const res = await fetch('/api/views/records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', recordId, viewId: view?.id })
      });
      if (res.ok) {
        setData(prev => prev.filter(r => r.id !== recordId));
      } else {
        alert('Error al eliminar el registro');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveNew = async () => {
    if (!view) return;
    try {
      setIsSaving(true);
      const finalData = { ...newRow };
      if (view.filter_key && filterValue) {
        finalData[view.filter_key] = filterValue;
      }

      const res = await fetch('/api/views/records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create',
          entityId: view.entity_id,
          viewId: view.id,
          data: finalData
        })
      });

      if (res.ok) {
        loadViewData();
        setNewRow({});
        setIsAdding(false);
      } else {
        alert('Error al guardar el nuevo registro');
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSaving(false);
    }
  };

  if (!view) return <div className="p-4 bg-slate-50 rounded-xl text-slate-400 text-xs italic">Vista no disponible en este momento.</div>;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center mb-2">
        {title && <h4 className="text-sm font-bold text-slate-600">{title}</h4>}
        {!isAdding && (
          <button onClick={() => setIsAdding(true)} className="px-3 py-1.5 bg-[#7CB342] text-white rounded-lg text-xs font-bold flex items-center gap-1 hover:bg-[#689f38] transition-all print:hidden">
            <Plus size={14} /> Nuevo Registro
          </button>
        )}
      </div>

      {isAdding && (
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {(view.columns || []).map((col: string) => (
              <div key={col}>
                <label className="block text-[10px] uppercase font-bold text-slate-400 mb-1">{col}</label>
                <input
                  type="text"
                  value={newRow[col] || ''}
                  onChange={e => setNewRow({ ...newRow, [col]: e.target.value })}
                  className="w-full text-xs p-2 bg-white border border-slate-200 rounded-lg outline-none"
                />
              </div>
            ))}
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={() => setIsAdding(false)} className="px-3 py-1.5 text-slate-400 font-bold text-xs">Cancelar</button>
            <button onClick={handleSaveNew} className="px-4 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-bold" disabled={isSaving}>
              {isSaving ? 'Guardando...' : 'Guardar'}
            </button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-slate-100 bg-white">
        <table className="w-full text-left border-collapse">
          <thead className="bg-slate-50">
            <tr>
              {(view.columns || []).map((col: string) => (
                <th key={col} className="px-4 py-3 text-[10px] font-black text-slate-400 uppercase tracking-widest">{col}</th>
              ))}
              <th className="px-4 py-3 w-10"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {loading ? (
              <tr><td colSpan={100} className="py-10 text-center text-slate-400 text-xs">Cargando datos...</td></tr>
            ) : data.length === 0 ? (
              <tr><td colSpan={100} className="py-10 text-center text-slate-400 text-xs">Sin resultados</td></tr>
            ) : (
              data.map((row, idx) => (
                <tr key={row.id || idx} className="hover:bg-slate-50 group">
                  {(view.columns || []).map((col: string) => (
                    <td key={col} className="px-4 py-3 text-xs text-slate-600">{row.data[col]}</td>
                  ))}
                  <td className="px-4 py-3 text-right">
                    <button onClick={() => handleDelete(row.id)} className="text-slate-200 hover:text-red-500 transition-colors">
                      <Trash2 size={12} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ─── Componente Home (Contenedor Principal) ────────────────────────────────────────────────
export default function Home() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [isUploading, setIsUploading] = useState(false);
  const [entities, setEntities] = useState<any[]>([]);
  const [relationships, setRelationships] = useState<any[]>([]);
  const [customViews, setCustomViews] = useState<any[]>([]);

  // Estados para CWP Report (Nuevos)
  const [selectedCWP, setSelectedCWP] = useState<any | null>(null);
  const [cwpNotes, setCwpNotes] = useState<Record<string, string>>({});
  const [cwpLinkedViews, setCwpLinkedViews] = useState<any[]>([]);
  const [showAddDashView, setShowAddDashView] = useState(false);
  const [addDashViewForm, setAddDashViewForm] = useState({ title: '', viewName: '' });

  // Estados para Auditoría
  const [auditResult, setAuditResult] = useState<any | null>(null);
  const [isAuditing, setIsAuditing] = useState(false);

  // Cargar datos iniciales
  useEffect(() => {
    const loadInitialData = async () => {
      const [entRes, relRes, viewRes] = await Promise.all([
        supabase.from('entities').select('*, attributes(*)'),
        supabase.from('relationships').select('*, parent_attr:attributes!parent_attribute_id(*, entity:entities(*)), child_attr:attributes!child_attribute_id(*, entity:entities(*))'),
        supabase.from('custom_views').select('*')
      ]);
      if (entRes.data) setEntities(entRes.data);
      if (relRes.data) setRelationships(relRes.data);
      if (viewRes.data) setCustomViews(viewRes.data);
    };
    loadInitialData();

    // Cargar notas de CWP desde localStorage
    const savedNotes = localStorage.getItem('cwp_notes');
    if (savedNotes) setCwpNotes(JSON.parse(savedNotes));

    // Cargar vistas vinculadas a CWP
    const savedLinked = localStorage.getItem('cwp_linked_views');
    if (savedLinked) setCwpLinkedViews(JSON.parse(savedLinked));
  }, []);

  const handleNotesChange = (cwpName: string, text: string) => {
    const updated = { ...cwpNotes, [cwpName]: text };
    setCwpNotes(updated);
    localStorage.setItem('cwp_notes', JSON.stringify(updated));
  };

  const handleAddDashView = () => {
    if (!addDashViewForm.title || !addDashViewForm.viewName) return;
    const newView = { id: Date.now(), ...addDashViewForm };
    const updated = [...cwpLinkedViews, newView];
    setCwpLinkedViews(updated);
    localStorage.setItem('cwp_linked_views', JSON.stringify(updated));
    setAddDashViewForm({ title: '', viewName: '' });
    setShowAddDashView(false);
  };

  const handleRemoveDashView = (id: number) => {
    const updated = cwpLinkedViews.filter(v => v.id !== id);
    setCwpLinkedViews(updated);
    localStorage.setItem('cwp_linked_views', JSON.stringify(updated));
  };

  const onDeleteRelationship = async (edgeId: string) => {
    console.log('Solicitando eliminación de relación:', edgeId);
    const { error } = await supabase.from('relationships').delete().eq('id', edgeId);
    if (!error) {
      console.log('Eliminación exitosa en Supabase, actualizando estado local.');
      setRelationships(prev => prev.filter(r => r.id !== edgeId));
    } else {
      console.error('Error al eliminar relación:', error);
    }
  };

  // --- Lógica de Ingesta y Visualización de Datos ---
  const [previewData, setPreviewData] = useState<any[]>([]);  // [{__id, data: {...}}]
  const [columns, setColumns] = useState<string[]>([]);
  const [columnFilters, setColumnFilters] = useState<Record<string, string>>({});
  const [selectedEntityForUpload, setSelectedEntityForUpload] = useState('');
  const [pendingFileName, setPendingFileName] = useState('');
  const [editingCell, setEditingCell] = useState<{ rowId: string; col: string } | null>(null);
  const [editingValue, setEditingValue] = useState('');
  const [batches, setBatches] = useState<{ batchId: string; batchName: string; count: number; created_at: string }[]>([]);
  const [renamingBatch, setRenamingBatch] = useState<string | null>(null);
  const [renamingValue, setRenamingValue] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [entitySummaries, setEntitySummaries] = useState<Record<string, { count: number; columns: string[]; lastUpload: string }>>({});

  // ─── Cargar resumen global de todas las entidades ─────────────────────────────
  useEffect(() => {
    const loadSummaries = async () => {
      if (entities.length === 0) return;
      const summaries: Record<string, { count: number; columns: string[]; lastUpload: string }> = {};
      await Promise.all(entities.map(async (ent) => {
        const { data } = await supabase
          .from('data_records').select('data, created_at')
          .eq('entity_id', ent.id).order('created_at', { ascending: false }).limit(50);
        if (data && data.length > 0) {
          const cols = Array.from(new Set(data.flatMap(r => Object.keys(r.data || {}).filter(k => !k.startsWith('_batch')))));
          summaries[ent.id] = { count: data.length, columns: cols.slice(0, 6), lastUpload: data[0].created_at };
        }
      }));
      setEntitySummaries(summaries);
    };
    loadSummaries();
  }, [entities]);


  // ─── Cargar datos y lotes al seleccionar entidad ──────────────────────────
  useEffect(() => {
    const fetchEntityData = async () => {
      if (!selectedEntityForUpload) { setPreviewData([]); setColumns([]); setBatches([]); return; }
      const { data, error } = await supabase
        .from('data_records').select('*').eq('entity_id', selectedEntityForUpload)
        .order('created_at', { ascending: false }).limit(500);
      if (!error && data && data.length > 0) {
        const rows = data.map(r => ({ __id: r.id, ...r.data }));
        setPreviewData(rows);
        const allKeys = Array.from(new Set(rows.flatMap(r => Object.keys(r).filter(k => k !== '__id'))));
        setColumns(allKeys);
        // Construir metadatos de lotes
        const batchMap: Record<string, { batchName: string; count: number; created_at: string }> = {};
        data.forEach(r => {
          const bid = r.data?._batch_id || 'sin_lote';
          const bname = r.data?._batch_name || 'Sin nombre';
          if (!batchMap[bid]) batchMap[bid] = { batchName: bname, count: 0, created_at: r.created_at };
          batchMap[bid].count++;
        });
        setBatches(Object.entries(batchMap).map(([batchId, v]) => ({ batchId, ...v })));
      } else {
        setPreviewData([]); setColumns([]); setBatches([]);
      }
    };
    fetchEntityData();
  }, [selectedEntityForUpload]);

  // ─── Cargar desde archivo Excel ───────────────────────────────────────────
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPendingFileName(file.name.replace(/\.[^.]+$/, ''));
    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const data: any[] = XLSX.utils.sheet_to_json(ws);
      if (data.length > 0) {
        const tempRows = data.map((row, idx) => ({ __id: `__temp_${idx}`, ...row }));
        setPreviewData(tempRows);
        setColumns(Object.keys(data[0]));
      }
    };
    reader.readAsBinaryString(file);
  };

  // ─── Guardar ingesta con metadatos de lote ────────────────────────────────
  const handleSaveIngestion = async () => {
    if (!selectedEntityForUpload || previewData.length === 0) return;
    setIsUploading(true);
    try {
      const batchId = `batch_${Date.now()}`;
      const batchName = pendingFileName || `Carga ${new Date().toLocaleDateString('es-ES')}`;
      const rows = previewData.map(row => {
        const { __id, ...data } = row;
        return { entity_id: selectedEntityForUpload, data: { ...data, _batch_id: batchId, _batch_name: batchName } };
      });
      const { error } = await supabase.from('data_records').insert(rows);
      if (!error) {
        setPendingFileName('');
        // Recargar datos
        const { data: fresh } = await supabase.from('data_records').select('*').eq('entity_id', selectedEntityForUpload).order('created_at', { ascending: false }).limit(500);
        if (fresh && fresh.length > 0) {
          const refreshed = fresh.map(r => ({ __id: r.id, ...r.data }));
          setPreviewData(refreshed);
          setColumns(Array.from(new Set(refreshed.flatMap(r => Object.keys(r).filter(k => k !== '__id')))));
          const batchMap: Record<string, any> = {};
          fresh.forEach(r => {
            const bid = r.data?._batch_id || 'sin_lote';
            if (!batchMap[bid]) batchMap[bid] = { batchName: r.data?._batch_name || 'Sin nombre', count: 0, created_at: r.created_at };
            batchMap[bid].count++;
          });
          setBatches(Object.entries(batchMap).map(([batchId, v]) => ({ batchId, ...v })));
        }
      } else { console.error('Ingesta fallida:', error); }
    } catch (e) { console.error(e); } finally { setIsUploading(false); }
  };

  // ─── Eliminar lote completo ───────────────────────────────────────────────
  const handleDeleteBatch = async (batchId: string) => {
    const ids = previewData.filter(r => r._batch_id === batchId).map(r => r.__id);
    if (ids.length === 0) return;
    const { error } = await supabase.from('data_records').delete().in('id', ids);
    if (!error) {
      setPreviewData(prev => prev.filter(r => r._batch_id !== batchId));
      setBatches(prev => prev.filter(b => b.batchId !== batchId));
    }
  };

  // ─── Renombrar lote ───────────────────────────────────────────────────────
  const handleRenameBatch = async (batchId: string, newName: string) => {
    const ids = previewData.filter(r => r._batch_id === batchId).map(r => r.__id);
    for (const id of ids) {
      const row = previewData.find(r => r.__id === id);
      if (!row) continue;
      const { __id, ...data } = row;
      await supabase.from('data_records').update({ data: { ...data, _batch_name: newName } }).eq('id', id);
    }
    setPreviewData(prev => prev.map(r => r._batch_id === batchId ? { ...r, _batch_name: newName } : r));
    setBatches(prev => prev.map(b => b.batchId === batchId ? { ...b, batchName: newName } : b));
    setRenamingBatch(null);
  };

  // ─── Edición inline ──────────────────────────────────────────────────────
  const handleCommitEdit = async () => {
    if (!editingCell) return;
    setIsSavingEdit(true);
    const row = previewData.find(r => r.__id === editingCell.rowId);
    if (row) {
      const { __id, ...data } = row;
      const updated = { ...data, [editingCell.col]: editingValue };
      if (!__id.startsWith('__temp_')) {
        await supabase.from('data_records').update({ data: updated }).eq('id', __id);
      }
      setPreviewData(prev => prev.map(r => r.__id === editingCell.rowId ? { ...r, [editingCell.col]: editingValue } : r));
    }
    setEditingCell(null);
    setIsSavingEdit(false);
  };

  // ─── Limpiar filas con vacíos ────────────────────────────────────────────
  const handleCleanBlanks = async () => {
    const emptyRows = previewData.filter(r => columns.some(col => !col.startsWith('_') && (r[col] === '' || r[col] === null || r[col] === undefined)));
    if (emptyRows.length === 0) { alert('No hay filas con valores vacíos.'); return; }
    const ids = emptyRows.map(r => r.__id).filter(id => !id.startsWith('__temp_'));
    if (ids.length > 0) await supabase.from('data_records').delete().in('id', ids);
    const emptySet = new Set(emptyRows.map(r => r.__id));
    setPreviewData(prev => prev.filter(r => !emptySet.has(r.__id)));
  };

  // ─── Filtrado de datos ───────────────────────────────────────────────────
  const visibleColumns = columns.filter(c => !c.startsWith('_batch_') && c !== '__id');
  const filteredData = previewData.filter(row =>
    Object.entries(columnFilters).every(([col, val]) =>
      !val || String(row[col] ?? '').toLowerCase().includes(val.toLowerCase())
    )
  );

  return (
    <main className="flex h-screen bg-[#F8FAFC] text-slate-900 font-sans overflow-hidden">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Content Area */}
      <section className="flex-1 flex flex-col min-w-0 bg-slate-50/50">
        <header className="h-20 bg-white border-b border-slate-200 flex items-center justify-between px-10 shadow-sm z-10 font-sans">
          <h2 className="text-sm font-black text-slate-400 uppercase tracking-[0.2em]">
            Módulo: {activeTab.toUpperCase()}
          </h2>
        </header>

        <div className="flex-1 overflow-y-auto p-10 relative">
          {activeTab === 'dashboard' && (
            <div className="space-y-12 animate-in fade-in duration-500">
              <div className="flex justify-between items-end">
                <div>
                  <h3 className="text-5xl font-black text-slate-900 tracking-tighter mb-2 italic">Dashboard de CWPs</h3>
                  <p className="text-sm text-slate-500 font-bold">Resumen de paquetes de trabajo y control de avance de construcción.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                <div 
                  className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:scale-[1.02] transition-all cursor-pointer group"
                  onClick={() => setSelectedCWP({ name: 'CWP-01-ME-101', activities: 145, hasMaterials: true })}
                >
                  <div className="flex justify-between items-start mb-10">
                    <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center text-[#7CB342] group-hover:bg-[#7CB342] group-hover:text-white transition-all">
                      <Activity size={28} />
                    </div>
                    <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-black rounded-full uppercase tracking-widest border border-emerald-100">Activo</span>
                  </div>
                  <h4 className="text-2xl font-black text-slate-900 mb-2 truncate group-hover:text-[#7CB342] transition-colors font-sans italic">CWP-01-ME-101</h4>
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest flex items-center gap-2">
                    <Layers size={14} /> 145 Actividades • Mecánico
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'upload' && (
            <div className="space-y-10 animate-in fade-in duration-500 pb-20">
              <div>
                <h3 className="text-5xl font-black text-slate-900 tracking-tighter mb-2 italic">Gestión de Datos</h3>
                <p className="text-sm text-slate-500 font-bold">Carga, edita y depura información estructurada de proyecto.</p>
              </div>

              {/* ── Panel de Control de Carga ── */}
              <div className="p-8 bg-white rounded-[2.5rem] border border-slate-100 shadow-xl flex flex-col md:flex-row gap-6 items-center">
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Entidad</label>
                  <select value={selectedEntityForUpload} onChange={e => { setSelectedEntityForUpload(e.target.value); setColumnFilters({}); }}
                    className="w-64 text-sm font-bold p-3 bg-slate-50 border border-slate-100 rounded-xl outline-none">
                    <option value="">Seleccionar Entidad...</option>
                    {entities.map(e => <option key={e.id} value={e.id}>{e.name}</option>)}
                  </select>
                </div>
                <div className="flex-1 border-2 border-dashed border-slate-200 rounded-2xl p-4 text-center relative group hover:border-[#7CB342]/40 transition-all cursor-pointer">
                  <div className="flex items-center justify-center gap-2 text-slate-400 group-hover:text-[#7CB342] transition-colors">
                    <Upload size={16} />
                    <span className="text-xs font-bold uppercase tracking-widest">
                      {pendingFileName ? `📄 ${pendingFileName}` : 'Arrastrar o clic para cargar Excel'}
                    </span>
                  </div>
                  <input type="file" accept=".xlsx,.xls,.csv" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleFileUpload} />
                </div>
                <div className="flex gap-3">
                  {pendingFileName && (
                    <button onClick={handleSaveIngestion} disabled={!selectedEntityForUpload || isUploading}
                      className="px-8 py-4 bg-[#7CB342] text-white rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-[#689f38] transition-all shadow-lg flex items-center gap-2">
                      {isUploading ? <Loader2 className="animate-spin" size={16} /> : <Save size={16} />}
                      {isUploading ? 'Guardando...' : 'Guardar'}
                    </button>
                  )}
                  {previewData.length > 0 && (
                    <button onClick={handleCleanBlanks}
                      className="px-8 py-4 bg-red-50 text-red-600 border border-red-100 rounded-2xl font-black text-[11px] uppercase tracking-widest hover:bg-red-100 transition-all flex items-center gap-2">
                      <Trash2 size={14} /> Limpiar Vacíos
                    </button>
                  )}
                </div>
              </div>

              {/* ── Panel de Lotes (Archivos Subidos) ── */}
              {batches.length > 0 && (
                <div className="space-y-4">
                  <h4 className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <FileText size={12} /> Archivos Subidos ({batches.length})
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                    {batches.map(batch => (
                      <div key={batch.batchId} className="bg-white rounded-2xl border border-slate-100 p-5 flex items-center gap-4 shadow-sm hover:shadow-md transition-all">
                        <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-300">
                          <FileText size={20} />
                        </div>
                        <div className="flex-1 min-w-0">
                          {renamingBatch === batch.batchId ? (
                            <input autoFocus value={renamingValue}
                              onChange={e => setRenamingValue(e.target.value)}
                              onBlur={() => handleRenameBatch(batch.batchId, renamingValue)}
                              onKeyDown={e => e.key === 'Enter' && handleRenameBatch(batch.batchId, renamingValue)}
                              className="w-full text-sm font-bold border-b border-[#7CB342] outline-none bg-transparent"
                            />
                          ) : (
                            <p className="text-sm font-black text-slate-800 truncate cursor-pointer hover:text-[#7CB342] transition-colors"
                              onDoubleClick={() => { setRenamingBatch(batch.batchId); setRenamingValue(batch.batchName); }}>
                              {batch.batchName}
                            </p>
                          )}
                          <p className="text-[10px] text-slate-400 font-bold">{batch.count} registros</p>
                        </div>
                        <div className="flex gap-2">
                          <button onClick={() => { setRenamingBatch(batch.batchId); setRenamingValue(batch.batchName); }}
                            className="p-2 text-slate-300 hover:text-[#7CB342] transition-colors" title="Renombrar">
                            <Settings size={14} />
                          </button>
                          <button onClick={() => handleDeleteBatch(batch.batchId)}
                            className="p-2 text-slate-300 hover:text-red-500 transition-colors" title="Eliminar lote">
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── Tabla de Datos con Filtros y Edición ── */}
              {previewData.length > 0 ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest">
                      {filteredData.length} de {previewData.length} registros
                      {isSavingEdit && <span className="ml-3 text-[#7CB342]">(Guardando...)</span>}
                    </p>
                    <button onClick={() => setColumnFilters({})}
                      className="text-[10px] font-black text-slate-400 hover:text-slate-700 uppercase tracking-widest flex items-center gap-1">
                      <X size={11} /> Borrar filtros
                    </button>
                  </div>
                  <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
                    <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                      <table className="w-full text-left border-collapse text-xs">
                        <thead className="bg-slate-50 sticky top-0 z-10">
                          <tr>
                            {visibleColumns.map(col => (
                              <th key={col} className="px-4 py-2 border-b border-slate-100">
                                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{col}</p>
                                <input
                                  value={columnFilters[col] || ''}
                                  onChange={e => setColumnFilters(prev => ({ ...prev, [col]: e.target.value }))}
                                  placeholder="Filtrar..."
                                  className="w-full text-[10px] px-2 py-1 bg-white border border-slate-200 rounded-lg outline-none focus:border-[#7CB342] transition-colors"
                                />
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          {filteredData.slice(0, 200).map((row) => (
                            <tr key={row.__id} className="hover:bg-slate-50/80 group transition-colors">
                              {visibleColumns.map(col => (
                                <td key={col} className="px-4 py-2 max-w-[180px]">
                                  {editingCell?.rowId === row.__id && editingCell?.col === col ? (
                                    <input autoFocus value={editingValue}
                                      onChange={e => setEditingValue(e.target.value)}
                                      onBlur={handleCommitEdit}
                                      onKeyDown={e => { if (e.key === 'Enter') handleCommitEdit(); if (e.key === 'Escape') setEditingCell(null); }}
                                      className="w-full text-xs px-2 py-1 border border-[#7CB342] rounded-lg outline-none bg-emerald-50"
                                    />
                                  ) : (
                                    <span
                                      onDoubleClick={() => { setEditingCell({ rowId: row.__id, col }); setEditingValue(String(row[col] ?? '')); }}
                                      className={`block truncate cursor-text hover:bg-slate-100 rounded px-1 py-0.5 transition-colors ${
                                        !row[col] && row[col] !== 0 ? 'text-red-300 italic' : 'text-slate-700'
                                      }`}
                                      title={`Doble clic para editar: ${String(row[col] ?? '')}`}
                                    >
                                      {row[col] !== null && row[col] !== undefined && row[col] !== '' ? String(row[col]) : '─'}
                                    </span>
                                  )}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : !selectedEntityForUpload && entities.length > 0 ? (
                <div className="space-y-6">
                  <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Database size={12} /> {entities.length} Tablas Disponibles — Clic para explorar
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                    {entities.map(ent => {
                      const summary = entitySummaries[ent.id];
                      return (
                        <button key={ent.id}
                          onClick={() => { setSelectedEntityForUpload(ent.id); setColumnFilters({}); }}
                          className="group text-left bg-white rounded-[2.5rem] border border-slate-100 p-8 shadow-sm hover:shadow-2xl hover:scale-[1.02] hover:border-[#7CB342]/30 transition-all duration-300">
                          <div className="flex items-start justify-between mb-6">
                            <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 group-hover:bg-[#7CB342]/10 group-hover:text-[#7CB342] transition-all">
                              <Database size={26} />
                            </div>
                            {summary ? (
                              <span className="px-3 py-1 bg-emerald-50 text-emerald-600 text-[10px] font-black rounded-full border border-emerald-100 uppercase tracking-widest">
                                {summary.count >= 50 ? '50+' : summary.count} reg.
                              </span>
                            ) : (
                              <span className="px-3 py-1 bg-slate-50 text-slate-400 text-[10px] font-black rounded-full border border-slate-100 uppercase tracking-widest">Vacía</span>
                            )}
                          </div>
                          <h4 className="text-xl font-black text-slate-900 leading-tight mb-3 italic tracking-tight group-hover:text-[#7CB342] transition-colors truncate">
                            {ent.name}
                          </h4>
                          {summary ? (
                            <div className="space-y-3">
                              <div className="flex flex-wrap gap-1.5">
                                {summary.columns.map(col => (
                                  <span key={col} className="px-2 py-0.5 bg-slate-50 border border-slate-100 rounded-lg text-[9px] font-black text-slate-400 uppercase tracking-wide">
                                    {col}
                                  </span>
                                ))}
                              </div>
                              <p className="text-[10px] text-slate-300 font-bold">
                                Última carga: {new Date(summary.lastUpload).toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })}
                              </p>
                            </div>
                          ) : (
                            <p className="text-xs text-slate-300 italic font-bold">Sin registros aún</p>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : selectedEntityForUpload ? (
                <div className="p-20 text-center border-2 border-dashed border-slate-200 rounded-[3rem] text-slate-300 italic font-bold">
                  [ Esta entidad no tiene registros aún. Sube un Excel para comenzar ]
                </div>
              ) : (
                <div className="p-20 text-center border-2 border-dashed border-slate-200 rounded-[3rem] text-slate-300 italic font-bold">
                  [ Cargando entidades... ]
                </div>
              )}
            </div>
          )}

          {activeTab === 'modeling' && (
            <div className="h-full flex flex-col space-y-8 animate-in fade-in duration-500">
              <div className="flex justify-between items-end shrink-0">
                <div>
                  <h3 className="text-4xl font-black text-slate-900 tracking-tighter mb-2 italic">Mapa Nodal de Información</h3>
                  <p className="text-sm text-slate-500 font-bold">Define las relaciones críticas entre entidades para la trazabilidad total.</p>
                </div>
                <div className="flex gap-3">
                  <button className="px-6 py-3 bg-[#7CB342] text-white rounded-2xl font-bold flex items-center gap-2 hover:bg-[#689f38] transition-all shadow-lg shadow-[#7CB342]/20">
                    <Plus size={18} /> Nueva Entidad
                  </button>
                </div>
              </div>

              <div className="flex-1 min-h-[600px] bg-white border border-slate-100 rounded-[2.5rem] shadow-sm overflow-hidden relative">
                <ReactFlowProvider>
                  <ModelingCanvas 
                    initialNodes={entities.map((e, idx) => ({
                      id: e.id,
                      type: 'entityNode',
                      position: { x: e.canvas_x || idx * 300, y: e.canvas_y || 100 },
                      data: { name: e.name, attributes: e.attributes }
                    }))}
                    initialEdges={relationships.map(r => ({
                      id: r.id,
                      source: r.parent_attr?.entity_id,
                      target: r.child_attr?.entity_id,
                      sourceHandle: r.parent_attr?.name,
                      targetHandle: r.child_attr?.name,
                      type: 'deletableEdge',
                      data: { onDelete: (id: string) => onDeleteRelationship(id) }
                    }))}
                    onSaveRelationship={async (conn) => {
                      if (!conn.source || !conn.target) return;
                      // Buscar IDs de atributos basados en los nombres de los handles
                      const sourceEnt = entities.find(e => e.id === conn.source);
                      const targetEnt = entities.find(e => e.id === conn.target);
                      const parentAttr = sourceEnt?.attributes.find((a: any) => a.name === conn.sourceHandle);
                      const childAttr = targetEnt?.attributes.find((a: any) => a.name === conn.targetHandle);

                      if (parentAttr && childAttr) {
                        const { data, error } = await supabase.from('relationships').insert({
                          parent_attribute_id: parentAttr.id,
                          child_attribute_id: childAttr.id,
                          project_id: '00000000-0000-0000-0000-000000000000',
                          cardinality: '1:N',
                          join_type: 'inner'
                        }).select('*, parent_attr:attributes!parent_attribute_id(*), child_attr:attributes!child_attribute_id(*)').single();

                        if (!error && data) {
                          setRelationships(prev => [...prev, data]);
                        }
                      }
                    }}
                    onDeleteRelationship={onDeleteRelationship}
                    onSaveNodePosition={async (nodeId, x, y) => {
                      await supabase.from('entities').update({ canvas_x: x, canvas_y: y }).eq('id', nodeId);
                    }}
                  />
                </ReactFlowProvider>
              </div>
            </div>
          )}

          {activeTab === 'explorer' && (
            <div className="h-full flex flex-col space-y-6 animate-in fade-in duration-500 pb-10">
              <div className="px-6 pt-6">
                <h3 className="text-4xl font-black text-slate-900 tracking-tighter mb-2 italic">Explorador Relacional</h3>
                <p className="text-sm text-slate-500 font-bold">Cruza y conecta datos de múltiples tablas basándose en el mapa nodal.</p>
              </div>
              
              <div className="flex-1 overflow-hidden">
                <RelationalExplorer 
                  entities={entities}
                  relationships={relationships}
                />
              </div>
            </div>
          )}

          {activeTab === 'audit' && (
            <div className="h-full animate-in fade-in duration-500 overflow-hidden">
              <IntegrityAudit 
                relationships={relationships}
                entities={entities}
              />
            </div>
          )}

          {activeTab === 'views' && (
            <div className="space-y-12 animate-in fade-in duration-500">
              <div className="flex justify-between items-end">
                <div>
                  <h3 className="text-5xl font-black text-slate-900 tracking-tighter mb-2 italic">Vistas Maestras</h3>
                  <p className="text-sm text-slate-500 font-bold">Configure y gestione las tablas de datos para el reporte AWP.</p>
                </div>
                <button className="px-8 py-4 bg-slate-900 text-white rounded-[1.5rem] font-black uppercase tracking-widest text-[11px] hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 flex items-center gap-3">
                  <Plus size={18} /> Crear Nueva Vista
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {customViews.map(view => (
                  <div key={view.id} className="bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm hover:shadow-2xl hover:scale-[1.02] transition-all group">
                    <div className="flex justify-between items-start mb-8">
                      <div className="w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 group-hover:bg-[#7CB342]/10 group-hover:text-[#7CB342] transition-colors">
                        <Database size={28} />
                      </div>
                      <button 
                        onClick={async () => {
                          if (!confirm('¿Eliminar vista?')) return;
                          await fetch(`/api/views?id=${view.id}`, { method: 'DELETE' });
                          setCustomViews(prev => prev.filter(v => v.id !== view.id));
                        }}
                        className="p-2 text-slate-200 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                    <h4 className="text-2xl font-black text-slate-900 mb-2 italic">{view.name}</h4>
                    <div className="flex flex-wrap gap-2">
                      {(view.columns || []).slice(0, 3).map((c: string) => (
                        <span key={c} className="px-2 py-1 bg-slate-50 text-slate-400 text-[9px] font-black uppercase rounded-lg border border-slate-100">{c}</span>
                      ))}
                      {(view.columns || []).length > 3 && <span className="text-[9px] font-black text-slate-300">+{view.columns.length - 3}</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>

      {/* REPORTE CWP (MODAL PREMIUM) */}
      {selectedCWP && (
        <div className="fixed inset-0 z-[100] flex justify-center items-start lg:p-8 xl:p-12 overflow-y-auto bg-slate-900/60 backdrop-blur-md animate-in fade-in duration-300 print:p-0 print:bg-white print:overflow-visible text-slate-900">
          <div className="fixed inset-0 print:hidden" onClick={() => setSelectedCWP(null)} />
          <div className="relative w-full max-w-7xl min-h-[1056px] bg-white shadow-2xl animate-in slide-in-from-bottom-8 duration-500 flex flex-col rounded-[2.5rem] overflow-hidden print:shadow-none print:m-0 print:rounded-none">

            {/* Botonera Flotante */}
            <div className="absolute top-8 right-8 flex gap-3 z-10 print:hidden">
              <button onClick={() => window.print()} className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-bold flex items-center gap-2 hover:bg-slate-800 transition-all shadow-xl shadow-slate-200">
                <Printer size={18} /> Exportar PDF
              </button>
              <button onClick={() => setSelectedCWP(null)} className="p-3 bg-white border border-slate-200 rounded-2xl text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all shadow-md flex items-center justify-center font-sans">
                <X size={24} />
              </button>
            </div>

            {/* Cabecera del Informe */}
            <div className="px-16 pt-16 pb-12 border-b border-slate-100 bg-white relative">
              <div className="flex justify-between items-start mb-12">
                <div>
                  <div className="text-[#7CB342] font-black text-3xl tracking-tighter mb-1 select-none flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#7CB342] rounded-xl flex items-center justify-center text-white text-lg shadow-lg shadow-[#7CB342]/20 font-sans italic">A</div>
                    <span className="font-sans">O3 SOLUTIONS</span>
                  </div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.3em] font-sans">Advanced Work Packaging System</p>
                </div>
                <div className="text-right font-sans">
                  <h1 className="text-sm font-black text-slate-900 uppercase tracking-[0.2em]">Construction Work Package Report</h1>
                  <p className="text-xs text-slate-500 font-medium mt-1 uppercase">Generated: {new Date().toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
              </div>
              <h2 className="text-7xl font-black text-slate-900 tracking-tighter italic font-sans">{selectedCWP.name}</h2>
            </div>

            {/* Contenido del Documento */}
            <div className="flex-1 px-16 py-12 space-y-16 bg-white print:overflow-visible">
              <div className="space-y-6 break-inside-avoid">
                <h3 className="text-[10px] font-black text-[#7CB342] uppercase tracking-[0.3em] flex items-center gap-3 font-sans">
                  <span className="w-8 h-[2px] bg-[#7CB342] rounded-full"></span>
                  1. Resumen Ejecutivo y Estado Actual
                </h3>
                <div className="print:hidden">
                  <textarea
                    className="w-full min-h-[180px] bg-slate-50/50 border-2 border-slate-100 rounded-[2rem] p-8 text-xl text-slate-700 font-serif italic leading-relaxed focus:ring-4 focus:ring-[#7CB342]/5 outline-none transition-all placeholder:text-slate-300 resize-none shadow-inner"
                    placeholder="Redacta aquí las observaciones críticas..."
                    value={cwpNotes[selectedCWP.name] || ''}
                    onChange={(e) => handleNotesChange(selectedCWP.name, e.target.value)}
                  />
                </div>
                <div className="hidden print:block text-slate-800 font-serif text-xl leading-relaxed whitespace-pre-wrap px-8 py-6 border-l-4 border-[#7CB342] bg-slate-50/30 rounded-r-3xl italic">
                  {cwpNotes[selectedCWP.name] || 'Sin observaciones documentales.'}
                </div>
              </div>

              <div className="space-y-12">
                {cwpLinkedViews.map((dv, index) => (
                  <div key={dv.id} className="relative group bg-white border border-slate-100 rounded-[2.5rem] shadow-sm overflow-hidden print:border-slate-200 print:shadow-none break-inside-avoid print:rounded-2xl">
                    <div className="bg-slate-50/50 px-8 py-4 border-b border-slate-100 flex justify-between items-center transition-colors">
                      <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-3 font-sans">
                        {index + 2}. {dv.title}
                      </h3>
                      <button onClick={() => handleRemoveDashView(dv.id)} className="text-red-500 hover:text-red-700 print:hidden">
                        <Trash2 size={16} />
                      </button>
                    </div>
                    <div className="px-10 pb-10 bg-white">
                      <EmbeddedView viewName={dv.viewName} filterValue={selectedCWP.name} customViews={customViews} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
